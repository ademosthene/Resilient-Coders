$(document).ready(function(){

  $('#zebra').on('click', function(){

    var val1 = parseInt($('#val1').val());
    var val2 = parseInt($('#val2').val());
    $('#h2').html(val1 + val2);

  })

  $('#lion').on('click', function(){

    var val1 = parseInt($('#val1').val());
    var val2 = parseInt($('#val2').val());
    $('#h2').html(val1 - val2);

  })

  $('#tiger').on('click', function(){

    var val1 = parseInt($('#val1').val());
    var val2 = parseInt($('#val2').val());
    $('#h2').html(val1 * val2);

  })

  $('#bear').on('click', function(){

    var val1 = parseInt($('#val1').val());
    var val2 = parseInt($('#val2').val());
    $('#h2').html(val1 / val2);

  })


})
